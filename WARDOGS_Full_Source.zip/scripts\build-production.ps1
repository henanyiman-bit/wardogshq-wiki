param(
  [Parameter(Mandatory=$true)]
  [string]$Site
)
$ErrorActionPreference = 'Stop'
$env:SITE = $Site
Write-Host "[1/5] npm install"
npm install
Write-Host "[2/5] astro check"
npm run check
Write-Host "[3/5] astro build"
npm run build
Write-Host "[4/5] pagefind"
npm run search
Write-Host "[5/5] offline verify"
node scripts/offline-verify.mjs
Write-Host "WARDOGS production build completed successfully. Output: dist/"
